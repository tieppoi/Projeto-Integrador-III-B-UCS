# Camada Business (BO)

Parte do projeto acadêmico responsável pelas regras de negócio.
